import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,access} from 'node:fs/promises';
import {join} from 'node:path';
import {candidate,capture,config,temp} from './fixtures.mjs';
const api=await import('./workflow.mjs').catch(e=>e.code==='ERR_MODULE_NOT_FOUND'?{}:Promise.reject(e));
const fn=name=>{assert.equal(typeof api[name],'function','Missing implementation: '+name);return api[name];};
const exportOK=async({results})=>({verification:{passed:true},count:results.length});
function fake(){
 const log=[];return {log,discoverBatch:async({keyword,checkpoint})=>{log.push('search:'+keyword);return {items:[{videoId:'7777777777777777777',authorId:'9999999999999999999',username:'example',description:keyword==='bible comedy'?'#christianskit':'christian discussion'}],hasMore:false,cursor:1,valid:true};},readProfile:async()=>{log.push('profile');const c=capture();c.profile.bio='public@example.com';c.pages[0].items[0].description='hello';return c;},finish:async()=>log.push('finish')};
}
test('顺序-SEQ-001/002 复用-CACHE-001 target reached still searches next word and reuses facts',async t=>{
 const runDir=await temp(t),browser=fake();const r=await fn('runCampaign')({config,runDir,browser,exporter:exportOK});
 assert.deepEqual(browser.log,['search:christian skits','profile','search:bible comedy','finish']);assert.equal(r.results.length,1);assert.equal(r.results[0].decision,'confirmed');assert.deepEqual(r.results[0].sourceKeywords,config.keywords);
 const state=JSON.parse(await readFile(join(runDir,'execution-state.json'),'utf8'));assert.equal(state.status,'completed');assert.equal(state.runtimeRunning,false);assert.equal(state.currentKeywordIndex,2);
});
test('完成-DONE-001 empty valid search exports an empty list',async t=>{
 const browser=fake();browser.discoverBatch=async()=>({items:[],hasMore:false,valid:true});const r=await fn('runCampaign')({config,runDir:await temp(t),browser,exporter:exportOK});assert.equal(r.status,'completed');assert.equal(r.results.length,0);
});
test('完成-DONE-002 unknown completion pauses without switching words',async t=>{
 const browser=fake();browser.discoverBatch=async()=>({items:[],hasMore:null,valid:true});const runDir=await temp(t),r=await fn('runCampaign')({config,runDir,browser,exporter:exportOK});assert.equal(r.status,'paused');assert.equal(r.currentKeywordIndex,0);assert(!browser.log.includes('finish'));
});
test('分页-PAGE-001 repeated cursor with new evidence continues; no progress pauses',async t=>{
 const browser=fake();let calls=0;browser.discoverBatch=async()=>({items:[{videoId:String(++calls<3?calls:2),authorId:'1',username:'one',description:'x'}],hasMore:true,cursor:1,valid:true});
 const r=await fn('runCampaign')({config,runDir:await temp(t),browser,exporter:exportOK});assert.equal(r.stopReason,'search_progress_stalled');assert.equal(calls,3);
});
test('恢复-RESUME-001 落盘-STORE-001/002 pause restores first-page facts and clears PID',async t=>{
 const runDir=await temp(t),browser=fake();const c=capture();c.pages[0].hasMore=true;browser.readProfile=async()=>c;browser.nextPosts=async()=>{throw Object.assign(new Error('control_lost'),{pause:true});};
 let r=await fn('runCampaign')({config,runDir,browser,exporter:exportOK});assert.equal(r.status,'paused');let s=JSON.parse(await readFile(join(runDir,'execution-state.json'),'utf8'));assert.equal(s.runtimeRunning,false);assert.equal(s.activeProcessId,null);assert.equal(s.currentKeywordIndex,0);
 browser.readProfile=async()=>{throw Error('email repeated');};browser.ensureProfile=async()=>{};browser.nextPosts=async()=>({statusCode:0,hasMore:false,items:[]});r=await fn('runCampaign')({config,runDir,browser,exporter:exportOK,resume:true});assert.equal(r.status,'completed');
});
test('导出-EXPORT-002 export failure resumes export only and finishes after verification',async t=>{
 const runDir=await temp(t),browser=fake();let r=await fn('runCampaign')({config,runDir,browser,exporter:async()=>{throw Error('disk full');}});assert.equal(r.status,'export_failed');assert(!browser.log.includes('finish'));
 browser.discoverBatch=async()=>{throw Error('must not search');};browser.readProfile=async()=>{throw Error('must not visit');};r=await fn('runCampaign')({config,runDir,browser,exporter:exportOK,resume:true});assert.equal(r.status,'completed');assert.equal(browser.log.at(-1),'finish');
});
test('落盘-STORE-001 active writer and changed resume config are rejected',async t=>{
 const runDir=await temp(t),browser=fake();await fn('runCampaign')({config,runDir,browser,exporter:exportOK});
 await assert.rejects(fn('runCampaign')({config:{...config,days:9},runDir,browser,exporter:exportOK,resume:true}),/config|configuration/i);
 await writeFile(join(runDir,'run.lock'),JSON.stringify({pid:process.pid}));await assert.rejects(fn('runCampaign')({config,runDir,browser,exporter:exportOK,resume:true}),/running|writer/i);
});
test('依赖-DEP-001 whole offline flow works with global fetch forbidden',async t=>{
 const old=globalThis.fetch;globalThis.fetch=()=>{throw Error('network forbidden');};try{assert.equal((await fn('runCampaign')({config,runDir:await temp(t),browser:fake(),exporter:exportOK})).status,'completed');}finally{globalThis.fetch=old;}
});
test('顺序-SEQ-001/002 two search pages finish before profiles and all extra authors export',async t=>{
 const browser=fake(),events=[];let pages=0;
 browser.discoverBatch=async({keyword})=>{events.push('search:'+keyword);const n=keyword===config.keywords[0]?++pages:1;return {valid:true,cursor:n,hasMore:keyword===config.keywords[0]&&n===1,items:[{videoId:String(n),authorId:String(n),username:'creator'+n,description:'#christianskit'}]};};
 browser.readProfile=async q=>{events.push('profile:'+q.username);return capture(q.username,q.authorIdHint);};
 const r=await fn('runCampaign')({config,runDir:await temp(t),browser,exporter:exportOK});assert.equal(r.results.length,2);assert.deepEqual(events.slice(0,5),['search:christian skits','search:christian skits','profile:creator1','profile:creator2','search:bible comedy']);assert.equal(r.output.count,2);
});
test('落盘-STORE-001 final author record survives crash before results and keyword pointer',async t=>{
 const runDir=await temp(t),browser=fake();await fn('runCampaign')({config,runDir,browser,exporter:exportOK});
 const state=JSON.parse(await readFile(join(runDir,'execution-state.json'),'utf8'));state.status='paused';state.currentKeywordIndex=0;state.keywords[0].stage='filtering';await writeFile(join(runDir,'execution-state.json'),JSON.stringify(state));await writeFile(join(runDir,'results.json'),'[]');
 browser.readProfile=async()=>{throw Error('completed author revisited');};const r=await fn('runCampaign')({config,runDir,browser,exporter:exportOK,resume:true});assert.equal(r.results.length,1);assert.equal(r.output.count,1);
});
test('去重-DEDUP-001 stable author rename reuses prior facts and retains both keywords',async t=>{
 const browser=fake();let visits=0;browser.discoverBatch=async({keyword})=>({valid:true,hasMore:false,items:[{videoId:'1',authorId:'9999999999999999999',username:keyword===config.keywords[0]?'oldname':'newname',description:'#christianskit'}]});browser.readProfile=async q=>{visits++;return capture(q.username,q.authorIdHint);};
 const r=await fn('runCampaign')({config,runDir:await temp(t),browser,exporter:exportOK});assert.equal(r.results.length,1);assert.equal(r.results[0].decision,'confirmed');assert.equal(r.results[0].username,'newname');assert.equal(visits,1);
});
test('配置-CONFIG-001 wrong resume space rejects before changing persisted task data',async t=>{
 const runDir=await temp(t),browser=fake();await fn('runCampaign')({config,runDir,browser,exporter:exportOK,spaceId:5});
 const before=await readFile(join(runDir,'candidate-queue.json'),'utf8');
 await assert.rejects(fn('runCampaign')({config,runDir,browser,exporter:exportOK,resume:true,spaceId:6}),/space mismatch/);
 assert.equal(await readFile(join(runDir,'candidate-queue.json'),'utf8'),before);
});
test('落盘-STORE-001 legacy directories cannot be silently converted to a new campaign',async t=>{
 const runDir=await temp(t),original=JSON.stringify({task:'old completed task'});await writeFile(join(runDir,'execution-state.json'),original);
 await assert.rejects(fn('runCampaign')({config,runDir,browser:fake(),exporter:exportOK}),/legacy|existing|directory/i);assert.equal(await readFile(join(runDir,'execution-state.json'),'utf8'),original);await assert.rejects(access(join(runDir,'config.json')));
});
test('完成-DONE-003 successful partial search bodies persist without finishing the word',async t=>{
 const runDir=await temp(t),browser=fake();browser.discoverBatch=async({onCheckpoint})=>{await onCheckpoint({partialBodies:[{statusCode:0,hasMore:false,items:[{videoId:'1',authorId:'2',username:'partial',description:'#christianskit'}]}]});throw Error('response_body_unavailable');};
 const r=await fn('runCampaign')({config,runDir,browser,exporter:exportOK});assert.equal(r.status,'paused');assert.equal(r.currentKeywordIndex,0);assert.equal(JSON.parse(await readFile(join(runDir,'candidate-queue.json'),'utf8')).length,1);
});
