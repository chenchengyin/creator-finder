import fs from 'node:fs/promises';
import {join} from 'node:path';
import assert from 'node:assert/strict';
import {navigateWith403Retry,isControlError} from '../tiktok-browser/access.mjs';
import {readSearchPage,parseSearchResponse} from '../tiktok-search/search.mjs';
import {collectVideoRegions} from '../tiktok-video-region/region.mjs';
import {runCampaign} from './workflow.mjs';
const pause=reason=>Object.assign(new Error(reason),{pause:true});
const canonical=url=>{try{const u=new URL(url);return u.origin+u.pathname+u.search;}catch{return '';}};
const scopeMatches=(actual,target)=>{try{const a=new URL(actual),b=new URL(target);return a.hostname===b.hostname&&a.pathname.replace(/\/$/,'')===b.pathname.replace(/\/$/,'')&&(b.pathname.startsWith('/search')?a.searchParams.get('q')===b.searchParams.get('q'):true);}catch{return false;}};
export function readProfilePage(){
 let d;try{d=JSON.parse(document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__')?.textContent).__DEFAULT_SCOPE__['webapp.user-detail'];}catch{}
 const u=d?.userInfo?.user,latest=[...document.querySelectorAll('button')].find(b=>/^(最新|Latest)$/i.test(b.textContent?.trim()||''));
 return {profileUrl:location.origin+location.pathname,username:u?.uniqueId,authorId:u?.id,secUid:u?.secUid,bio:u?.signature||'',statusCode:d?.statusCode,privateAccount:u?.privateAccount,followers:d?.userInfo?.statsV2?.followerCount??d?.userInfo?.stats?.followerCount,capturedAt:new Date().toISOString(),latestOrderConfirmed:latest?.dataset.active==='true'||latest?.getAttribute('aria-selected')==='true',playlists:[...document.querySelectorAll('a[href*="/playlist/"]')].map(a=>({text:a.innerText,url:a.href}))};
}
function parsePosts(data){return {statusCode:data.statusCode,hasMore:[1,true].includes(data.hasMore)?true:[0,false].includes(data.hasMore)?false:null,cursor:data.cursor,items:(data.itemList||[]).map(i=>({id:i.id,authorId:i.author?.id,username:i.author?.uniqueId,createdAt:Number(i.createTime),views:i.statsV2?.playCount??i.stats?.playCount,description:i.desc||'',pinned:i.isPinnedItem===true,privateItem:i.privateItem===true,mediaType:i.imagePost?'photo':'video',locationCreated:i.locationCreated,capturedAt:new Date().toISOString(),url:'https://www.tiktok.com/@'+i.author?.uniqueId+'/video/'+i.id,source:'ego_passive_profile_item_list'}))};}
export function createEgoBrowser({page,task,runDir,config,sleep=ms=>new Promise(r=>setTimeout(r,ms)),now=()=>Date.now()}){
 const pacePath=join(runDir,'last-tiktok-nav.txt');
 const paced=async()=>{let last=0;try{last=Number(await fs.readFile(pacePath,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}assert(Number.isFinite(last)&&last>=0&&last<=now()+1000,'invalid shared navigation timestamp');const ms=Math.max(0,10500-(now()-last));if(ms)await sleep(ms);await fs.writeFile(pacePath,String(now()));};
 const scroll=()=>page.evaluate(()=>{let root=document.querySelector('[data-e2e="user-post-item"],a[href*="/video/"]')?.parentElement;while(root&&!(root.clientHeight>100&&root.scrollHeight>root.clientHeight+100&&/auto|scroll/.test(getComputedStyle(root).overflowY)))root=root.parentElement;root=root||document.scrollingElement;root.scrollTop=root.scrollHeight;});
 async function action({url,endpoint,keyword,checkpoint={},onCheckpoint=async()=>{},scrollPage=false,trigger,readyToSkip}){
  await page.cdp('Network.enable',{});
  const prior403=checkpoint.retry?.url===url&&checkpoint.retry.status===403&&checkpoint.retry.attempts===1;
  if(!prior403&&checkpoint.retry?.url===url&&[401,403,429].includes(checkpoint.retry.status)){
   const current=await page.evaluate(readSearchPage);
   if(!scopeMatches(current.url,url)||current.captcha||current.loginPrompt||current.httpStatus!==200)throw pause('http_'+checkpoint.retry.status);
   checkpoint={...checkpoint,retry:null};
  }
  let captured=[],first=!prior403,skipBodies=false;
  const inspect=async()=>{
   let all=[],access,start=now();
   for(;;){
    access=await page.evaluate(readSearchPage);all.push(...await page.events());
    const requests=new Map(all.filter(e=>e.method==='Network.requestWillBeSent').map(e=>[e.params.requestId,e.params]));
    const candidates=all.filter(e=>e.method==='Network.responseReceived'&&new URL(e.params.response.url).pathname===endpoint);
    captured=candidates.filter(e=>{const u=new URL(e.params.response.url),request=requests.get(e.params.requestId);return (!keyword||[u.searchParams.get('keyword'),u.searchParams.get('q')].includes(keyword))&&!!request&&scopeMatches(request.documentURL,url);});
    const statuses=[access.httpStatus,...captured.map(e=>e.params.response.status)];
    const status=statuses.find(s=>s===401||s===429)??statuses.find(s=>s===403)??statuses.find(s=>s>=400)??access.httpStatus;
    access={...access,httpStatus:status};
    if(access.captcha||access.loginPrompt||status>=400)break;
    if(!scopeMatches(access.url,url))throw pause('page_identity_mismatch');
    const readiness=readyToSkip?await readyToSkip():false;
    if(readiness===true){skipBodies=true;break;}
    if(candidates.length&&!captured.length)throw pause('response_provenance_mismatch');
    if(captured.length&&readiness!=='wait'){
     const finished=new Set(all.filter(e=>e.method==='Network.loadingFinished').map(e=>e.params.requestId));
     if(captured.every(e=>finished.has(e.params.requestId)))break;
     // A response may already be complete before Network.enable; getResponseBody below is the final check.
     if(now()-start>=1000)break;
    }
    if(now()-start>=12000)throw pause(candidates.length?'response_provenance_mismatch':'response_missing');
    await sleep(100);
   }
   return access;
  };
  const nav=await navigateWith403Retry({page:{goto:async()=>{if(first&&trigger){first=false;await trigger();}else if(first&&scrollPage){first=false;await scroll();}else{first=false;await page.goto(url);}}},url,prior403,read:inspect,sleep,beforeNavigate:async()=>{await paced();await page.events();},onAttempt:async attempt=>{checkpoint={...checkpoint,retry:{url,attempts:attempt.number,status:attempt.httpStatus}};await onCheckpoint(checkpoint);await fs.appendFile(join(runDir,'access-attempts.jsonl'),JSON.stringify({url,number:attempt.number,httpStatus:attempt.httpStatus,capturedAt:attempt.capturedAt})+'\n');}});
  if(nav.access.captcha)throw pause('captcha_requires_user');if(nav.access.loginPrompt)throw pause('login_prompt_needs_inspection');if(nav.access.httpStatus>=400)throw pause('http_'+nav.access.httpStatus);if(nav.error)throw pause(nav.error);
  if(skipBodies){await onCheckpoint({...checkpoint,retry:null});return [];}
  const bodies=[];
  for(const event of captured){try{const response=await page.cdp('Network.getResponseBody',{requestId:event.params.requestId});bodies.push(JSON.parse(response.base64Encoded?Buffer.from(response.body,'base64').toString('utf8'):response.body));}catch(error){if(isControlError(error))throw error;await onCheckpoint({...checkpoint,partialBodies:bodies.map(b=>keyword?parseSearchResponse(b):parsePosts(b))});throw pause('response_body_unavailable');}}
  if(!bodies.length)throw pause('response_missing');await onCheckpoint({...checkpoint,retry:null});bodies.restarted=nav.retried;return bodies;
 }
 const browser={
  async discoverBatch({keyword,checkpoint={},onCheckpoint}){
   const url='https://www.tiktok.com/search/video?q='+encodeURIComponent(keyword);
   const bodies=await action({url,endpoint:'/api/search/item/full/',keyword,checkpoint,onCheckpoint,scrollPage:checkpoint.started===true&&scopeMatches(await page.url(),url)});
   const responses=bodies.map(parseSearchResponse);if(responses.some(r=>r.statusCode!==0||r.hasMore===null))throw pause('search_response_invalid');
   const result={items:responses.flatMap(r=>r.items),hasMore:responses.at(-1).hasMore,cursor:responses.at(-1).cursor,valid:true,checkpoint:{keyword,started:true,retry:null}};
   await fs.appendFile(join(runDir,'tiktok-video-discovery.jsonl'),JSON.stringify({keyword,url,capturedAt:new Date().toISOString(),responses})+'\n');return result;
  },
  async readProfile(candidate,onCheckpoint=async()=>{},checkpoint={}){
   const url='https://www.tiktok.com/@'+candidate.username;let profile,lastSaved;
   const inspectProfile=async()=>{
    const raw=await page.evaluate(readProfilePage);
    const identityVerified=raw.statusCode===0&&raw.username?.toLowerCase()===candidate.username.toLowerCase()&&(!candidate.authorIdHint||raw.authorId===candidate.authorIdHint);
    profile={...raw,identityVerified,ready:identityVerified};
    if(raw.authorId&&raw.authorId!==lastSaved){lastSaved=raw.authorId;await onCheckpoint({...checkpoint,profile});}
    if(!raw.authorId&&typeof raw.statusCode!=='number')return 'wait';
    return !raw.authorId||!identityVerified||raw.privateAccount||((config?.requireBioEmail??true)&&!raw.bio?.includes('@'))||!raw.latestOrderConfirmed;
   };
   let bodies=await action({url,endpoint:'/api/post/item_list/',checkpoint,onCheckpoint,readyToSkip:inspectProfile});
   if(profile?.ready&&!profile.privateAccount&&!profile.latestOrderConfirmed&&(!(config?.requireBioEmail??true)||profile.bio?.includes('@'))){
    bodies=await action({url,endpoint:'/api/post/item_list/',onCheckpoint,trigger:()=>page.evaluate(()=>{const b=[...document.querySelectorAll('button')].find(b=>/^(最新|Latest)$/i.test(b.textContent?.trim()||''));if(!b)throw Error('latest_sort_unavailable');b.click();})});
   }
   const raw=await page.evaluate(readProfilePage);const identityVerified=raw.statusCode===0&&raw.username?.toLowerCase()===candidate.username.toLowerCase()&&(!candidate.authorIdHint||raw.authorId===candidate.authorIdHint);
   return {profile:{...raw,identityVerified,ready:identityVerified},pages:bodies.map(parsePosts),postAttemptComplete:true};
  },
  async ensureProfile(candidate){if(!scopeMatches(await page.url(),'https://www.tiktok.com/@'+candidate.username))return browser.readProfile(candidate);},
  async nextPosts(candidate,capture,onCheckpoint){const bodies=await action({url:capture.profile.profileUrl,endpoint:'/api/post/item_list/',checkpoint:capture.access,onCheckpoint,scrollPage:true});const pages=bodies.map(parsePosts);pages.restarted=bodies.restarted;return pages;},
  async collectRegion(capture,save){const last=capture.videoRegion?.navigationAttempts?.at(-1);if(last?.httpStatus===403&&last.number>=2){const access=await page.evaluate(readSearchPage);if(access.httpStatus!==200||!scopeMatches(access.url,last.url)||access.captcha||access.loginPrompt)throw pause('http_403');}const report=await collectVideoRegions({page,capture,limit:1,beforeNavigate:paced,sleep,save,prior403:capture.videoRegion?.navigationAttempts?.at(-1)?.httpStatus===403});if(report.stopped)throw pause(report.stopReason);return report;},
  finish:async()=>{if(task)await task.finish({keep:[]});}
 };return browser;
}
export async function runInEgo(options,{listTaskSpaces,taskSpace}){
 const space=(await listTaskSpaces()).find(s=>s.id===options.spaceId);assert(space&&['agent','agentOwned'].includes(space.ownership),'original space requires Agent control ownership');
 const task=await taskSpace(options.spaceId),page=task.page('p1');
 const result=await runCampaign({...options,browser:createEgoBrowser({page,task,config:options.config,runDir:options.runDir})});
 if(result.status==='paused'&&/^(http_(401|403|429)|captcha)/.test(result.stopReason||''))await task.handOff();
 return result;
}
