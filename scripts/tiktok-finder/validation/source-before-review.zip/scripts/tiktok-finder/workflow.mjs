import fs from 'node:fs/promises';
import {join} from 'node:path';
import assert from 'node:assert/strict';
import {inputConfig,assertResumeCompatible} from './config.mjs';
import {mergeCandidates} from '../tiktok-search/search.mjs';
import {qualifyCandidate} from './profile.mjs';
import {exportResults} from './export.mjs';
export const readJson=async(path,fallback)=>{try{return JSON.parse(await fs.readFile(path,'utf8'));}catch(e){if(e.code==='ENOENT')return fallback;throw e;}};
export async function writeJson(path,value){const temp=path+'.tmp-'+process.pid;await fs.writeFile(temp,JSON.stringify(value,null,2)+'\n');await fs.rename(temp,path);}
const alive=pid=>{try{process.kill(pid,0);return true;}catch(e){return e.code!=='ESRCH';}};
export async function runCampaign({config,runDir,browser,exporter=exportResults,onProgress=async()=>{},resume=false,spaceId}){
 assert(config?.keywords?.length&&config.windowStart&&config.windowEndExclusive,'invalid frozen configuration');
 await fs.mkdir(runDir,{recursive:true});
 const lockPath=join(runDir,'run.lock');let lock;
 try{lock=await fs.open(lockPath,'wx');}catch(e){
  if(e.code!=='EEXIST')throw e;const old=await readJson(lockPath,{});assert(old.pid&&Number.isSafeInteger(old.pid),'invalid writer lock');assert(!alive(old.pid),'another writer is running');assert(resume,'stale writer requires resume');await fs.unlink(lockPath);lock=await fs.open(lockPath,'wx');
 }
 await lock.writeFile(JSON.stringify({pid:process.pid}));await lock.close();
 let state,queue,results;
 const statePath=join(runDir,'execution-state.json'),queuePath=join(runDir,'candidate-queue.json'),resultsPath=join(runDir,'results.json');
 const persist=async()=>{state.counts={uniqueCandidates:queue.length,processed:results.length,confirmed:results.filter(r=>r.decision==='confirmed').length,suspected:results.filter(r=>r.decision==='suspected').length};await writeJson(queuePath,queue);await writeJson(resultsPath,results);await writeJson(statePath,state);await onProgress({status:state.status,currentKeywordIndex:state.currentKeywordIndex,stage:state.stage,counts:state.counts});};
 try{
  const saved=await readJson(join(runDir,'config.json'),null);
  if(saved){assert(resume,'run already exists; use resume');assertResumeCompatible(saved,inputConfig(config));assert.deepEqual(saved,config,'resume configuration mismatch');}
  else{assert(!resume,'nothing to resume');assert(!await readJson(statePath,null),'existing legacy run directory cannot be reused');await writeJson(join(runDir,'config.json'),config);}
  const loadedState=await readJson(statePath,{schemaVersion:1,status:'running',stage:'searching',currentKeywordIndex:0,keywords:config.keywords.map(keyword=>({keyword,stage:'pending',checkpoint:{}})),browser:{spaceId,pageLabel:'p1'},counts:{}});
  if(spaceId!==undefined){assert(!loadedState.browser.spaceId||loadedState.browser.spaceId===spaceId,'original space mismatch');loadedState.browser.spaceId=spaceId;}
  queue=await readJson(queuePath,[]);results=await readJson(resultsPath,[]);
  state=loadedState;
  const upsert=result=>{const index=results.findIndex(r=>(r.authorId&&r.authorId===result.authorId)||(!r.authorId&&r.username.toLowerCase()===result.username.toLowerCase()));if(index<0)results.push(result);else if((result.processedKeywords?.length||0)>=(results[index].processedKeywords?.length||0))results[index]=result;};
  // Author records commit before queue/index updates. Reconcile them after an interrupted write.
  for(const file of (await fs.readdir(runDir)).filter(f=>/^author-[\w.-]+\.json$/.test(f))){const result=await readJson(join(runDir,file));upsert(result);for(const candidate of queue){if((!candidate.authorIdHint||candidate.authorIdHint===result.authorId)&&(candidate.username.toLowerCase()===result.username.toLowerCase()||(candidate.aliases||[]).includes(result.profile?.username))&&typeof result.authorId==='string'&&/^\d+$/.test(result.authorId))candidate.authorIdHint=result.authorId;}}
  if(state.status==='completed')return {...state,results,runtimeRunning:false,activeProcessId:null};
  state.runtimeRunning=true;state.activeProcessId=process.pid;state.status='running';state.stopReason=null;await persist();
  while(state.currentKeywordIndex<config.keywords.length){
   const record=state.keywords[state.currentKeywordIndex],keyword=record.keyword;
   if(record.stage==='pending')record.stage='searching';state.stage=record.stage;
   while(record.stage==='searching'){
    const response=await browser.discoverBatch({keyword,checkpoint:record.checkpoint,onCheckpoint:async checkpoint=>{record.checkpoint=checkpoint;if(checkpoint.partialBodies)queue=mergeCandidates(queue,checkpoint.partialBodies.filter(r=>r.statusCode===0).flatMap(r=>r.items),{keyword,sourceUrl:'https://www.tiktok.com/search/video?q='+encodeURIComponent(keyword),capturedAt:new Date().toISOString()}).queue;await persist();}});
    assert(response&&Array.isArray(response.items),'search_response_missing');
    const before=new Set(queue.flatMap(c=>c.sourceEvidence||[]).map(e=>e.keyword+':'+e.videoId));
    queue=mergeCandidates(queue,response.items,{keyword,sourceUrl:'https://www.tiktok.com/search/video?q='+encodeURIComponent(keyword),capturedAt:new Date().toISOString()}).queue;
    const newEvidence=queue.flatMap(c=>c.sourceEvidence||[]).some(e=>!before.has(e.keyword+':'+e.videoId));
    const oldCursor=record.checkpoint?.cursor;record.checkpoint={...record.checkpoint,...response.checkpoint,keyword,cursor:response.cursor??record.checkpoint?.cursor};await persist();
    assert(response.valid===true&&typeof response.hasMore==='boolean','search_completion_unknown');
    if(response.hasMore===false){record.stage='filtering';record.checkpoint.exhausted=true;state.stage='filtering';await persist();break;}
    assert(newEvidence||response.cursor!==oldCursor,'search_progress_stalled');
   }
   for(const candidate of queue.filter(c=>(c.sourceEvidence||[]).some(e=>e.keyword===keyword))){
    const key=candidate.authorIdHint||candidate.username.toLowerCase();
    state.currentAuthor=key;
    const finalPath=join(runDir,'author-'+key+'.json');const prior=await readJson(finalPath,null);
    if(prior?.processedKeywords?.includes(keyword))continue;
    const capturePath=join(runDir,'capture-'+key+'.json');
    const cachedCapture=prior?.capture||await readJson(capturePath,null);
    const result=await qualifyCandidate({candidate,config,browser,cachedCapture,onCheckpoint:c=>writeJson(capturePath,c)});
    result.processedKeywords=[...new Set([...(prior?.processedKeywords||[]),keyword])];
    const stableId=typeof result.authorId==='string'&&/^\d+$/.test(result.authorId)?result.authorId:null;
    await writeJson(stableId?join(runDir,'author-'+stableId+'.json'):finalPath,result);
    if(stableId)candidate.authorIdHint=stableId;upsert(result);
    candidate.status='checked';candidate.decision=result.decision;
    state.counts={uniqueCandidates:queue.length,processed:results.length,confirmed:results.filter(r=>r.decision==='confirmed').length,suspected:results.filter(r=>r.decision==='suspected').length};await persist();
   }
   record.stage='completed';state.currentKeywordIndex++;state.currentAuthor=null;await persist();
  }
  state.stage='exporting';state.status='exporting';await persist();
  try{
   state.output=await exporter({runDir,results:results.filter(r=>['confirmed','suspected'].includes(r.decision)),config});
   assert(state.output?.verification?.passed,'export verification failed');
  }catch(e){state.status='export_failed';state.stopReason=e.message;await persist();return {...state,results,runtimeRunning:false,activeProcessId:null};}
  if(browser.finish)await browser.finish();state.status='completed';state.stage='completed';await persist();return {...state,results,runtimeRunning:false,activeProcessId:null};
 }catch(error){
  if(!state)throw error;
  state.status='paused';state.stopReason=error.message;state.resumeStage=state.stage;await persist();return {...state,results,runtimeRunning:false,activeProcessId:null};
 }finally{
  try{if(state){state.runtimeRunning=false;state.activeProcessId=null;await writeJson(statePath,state);}}finally{await fs.unlink(lockPath).catch(e=>{if(e.code!=='ENOENT')throw e;});}
 }
}
