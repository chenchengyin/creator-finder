import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,stat} from 'node:fs/promises';
import {candidate,capture,config,temp} from './fixtures.mjs';
const api=await import('./export.mjs').catch(e=>e.code==='ERR_MODULE_NOT_FOUND'?{}:Promise.reject(e));
const fn=name=>{assert.equal(typeof api[name],'function','Missing implementation: '+name);return api[name];};
test('导出-EXPORT-001 actual XLSX preserves identifiers, sources, suspected and formulas',async t=>{
 const profile=await import('./profile.mjs');const c=capture();c.profile.bio='=public@example.com';
 const r=profile.evaluateCapture({candidate:candidate(),capture:c,config});r.sourceKeywords=config.keywords;r.decision='suspected';r.content.uncertainty='待人工复核';
 const out=await fn('exportResults')({runDir:await temp(t),results:[r],config,render:true});assert.equal(out.verification.passed,true);assert.equal(out.verification.creatorCount,1);assert((await stat(out.path)).size>1000);assert.equal(out.previews.length,3);
 const audit=JSON.parse(await readFile(out.auditPath,'utf8'));assert.equal(audit.authors[0].authorId,'9999999999999999999');assert.equal(audit.authors[0].averageViews,60000);assert.equal(audit.authors[0].decision,'suspected');
});
test('导出-EXPORT-002 zero results still produce headers and target shortfall',async t=>{
 const out=await fn('exportResults')({runDir:await temp(t),results:[],config});assert.equal(out.verification.passed,true);assert.equal(out.verification.creatorCount,0);assert.equal(out.verification.shortfall,1);
});
