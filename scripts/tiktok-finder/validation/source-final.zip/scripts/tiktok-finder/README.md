# TikTok多关键词查找

入口为[find.mjs](find.mjs)。[设计](docs/2026-10-21-多关键词顺序查找-设计.md)、[测试契约](docs/2026-10-21-多关键词顺序查找-测试用例.md)、[实现计划](docs/2026-10-21-多关键词顺序查找-实现计划.md)和Review记录均与代码放在本模块内。

按输入顺序逐词搜完、筛完，再进入下一词；达到目标人数继续执行，最终导出全部唯一作者。当前Bio公开邮箱、完整时间窗口均播和目标视频地区字段仍是必要数据条件；内容有歧义时以“疑似符合”交付并保留依据。地区字段不证明本人现居地。

## 操作入口

需要Node.js、Ego Lite及`ego-browser`。真实新任务先由主助手按Ego流程创建一次空间，记录spaceId并设置`FINDER_SPACE_ID`，随后一直复用该空间的p1。脚本不创建替代空间、不自行接管。历史空间328已关闭，不能拿来跑新任务。

先复制[配置示例](config.example.json)并修改实际条件。示例只用于说明格式，不代表一次真实采集授权。下列`runs/新批次`应换成独立的新批次目录。

```bash
# 本地校验，不创建任务目录或访问浏览器
node /Users/vb/Projects/creator-finder/scripts/tiktok-finder/find.mjs \
  --config /Users/vb/Projects/creator-finder/scripts/tiktok-finder/config.example.json \
  --run-dir /Users/vb/Projects/creator-finder/runs/新批次 --dry-run

# 开始实际已指定任务，FINDER_SPACE_ID填本批已有且由Agent控制的空间ID
node /Users/vb/Projects/creator-finder/scripts/tiktok-finder/find.mjs \
  --config /Users/vb/Projects/creator-finder/scripts/tiktok-finder/config.example.json \
  --run-dir /Users/vb/Projects/creator-finder/runs/新批次 --space "$FINDER_SPACE_ID"

# 在原配置、原窗口及原空间恢复；无需重新传配置
node /Users/vb/Projects/creator-finder/scripts/tiktok-finder/find.mjs \
  --run-dir /Users/vb/Projects/creator-finder/runs/新批次 --resume

# 查看进度，或在任务暂停后导出当前已核验的候选
node /Users/vb/Projects/creator-finder/scripts/tiktok-finder/find.mjs \
  --run-dir /Users/vb/Projects/creator-finder/runs/新批次 --status
node /Users/vb/Projects/creator-finder/scripts/tiktok-finder/find.mjs \
  --run-dir /Users/vb/Projects/creator-finder/runs/新批次 --export
```

启动前固定上海时间的完整自然日窗口；恢复不跨日重算窗口，不接受改变关键词顺序或筛选条件。`country=null`不筛地区，省去额外详情访问；`requireBioEmail=false`允许无邮箱。没有隐藏粉丝或最少作品数门槛。

所有导航、排序和翻页共享至少10.5秒间隔，串行操作。只被动读取正常页面产生的响应，校验请求所属页面和关键词，不生成签名或重放后台请求。

普通403在同址等11秒重试一次，重试状态随动作保存；401/429、验证码及控制权异常优先暂停。预算已用尽且原页仍受限时，再次运行不会增加重试。用户恢复原页并交还Agent控制后，使用resume继续。丢失原页可能需正常滚动重经已见页面，但已核验作者不重新打开，已采作品不重复计数。

## 状态与输出

`config.json`固定参数；`execution-state.json`保存当前词、阶段、作者、计数和停止原因；`candidate-queue.json`保留来源；`capture-*.json`保存逐项检查及未完成动作；`author-*.json`先于总进度提交，恢复时据此核对结果；`results.json`保留包括排除/数据不足在内的全部判定。有效writer锁阻止重复启动，强制终止后resume核对旧PID再清遗留锁。历史目录不能转成新任务。

XLSX含达人名单、主页证据、视频证据，逐人有收录依据、全部来源词及复核状态。数据条件未核实的记录不进入最终候选名单。导出失败恢复只做导出；表格公式核对通过后才完成任务并关闭原空间。

导出复用Artifact Tool：优先使用正常安装的`@oai/artifact-tool`，再尝试Codex内置运行时；非本机环境可通过`CREATOR_FINDER_NODE_MODULES`指定安装该包的node_modules目录。不调用大模型API。

## 验证边界

```bash
node --test scripts/tiktok-finder/*.test.mjs
node --test scripts/tiktok-browser/access.test.mjs scripts/tiktok-search/search.test.mjs scripts/tiktok-video-region/region.test.mjs
```

本轮验证：新增46项与原组件44项均通过，合计90/90。两轮Brainstorming有界只读实现Review已完成，两个发现均修复并复验；独立Reviewer/PR Review未做，详见[验证记录](docs/2026-10-21-开发验证与实现Review.md)。

离线联调目录`validation/offline-run/`使用虚构账号，仅用于检验顺序、全量导出、依据、公式和长ID，不能当成真实达人名单。既有5人的历史数据仅用于本地回放，未改变原任务或表格。

本次没有启动新TikTok批次，真实站点端到端尚未验收；也未在原生Excel中打开验证。Artifact预览可能把数字形式的文本ID显示为科学记数法，保存的XLSX须另查XML确认ID原值和文本类型。
