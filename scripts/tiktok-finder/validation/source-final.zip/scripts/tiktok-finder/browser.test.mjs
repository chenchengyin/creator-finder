import test from 'node:test';
import assert from 'node:assert/strict';
import {temp,capture,candidate,config} from './fixtures.mjs';
const api=await import('./browser.mjs').catch(e=>e.code==='ERR_MODULE_NOT_FOUND'?{}:Promise.reject(e));
const fn=name=>{assert.equal(typeof api[name],'function','Missing implementation: '+name);return api[name];};
function pageFixture({statuses=[200],apiStatuses=[200],queries,failBody=false}={}){
 let nav=0,buffer=[],url='',scrolls=0;const keyword='christian skits';
 const make=()=>apiStatuses.flatMap((status,i)=>[{method:'Network.requestWillBeSent',params:{requestId:String(i),documentURL:url}},{method:'Network.responseReceived',params:{requestId:String(i),response:{url:'https://www.tiktok.com/api/search/item/full/?keyword='+encodeURIComponent(queries?.[i]||keyword),status}}},{method:'Network.loadingFinished',params:{requestId:String(i)}}]);
 return {get nav(){return nav;},get scrolls(){return scrolls;},page:{url:async()=>url,events:async()=>{const v=buffer;buffer=[];return v;},goto:async value=>{url=value;nav++;buffer=make();},evaluate:async f=>{if(f.name==='readSearchPage')return {url,httpStatus:statuses[Math.min(nav-1,statuses.length-1)],links:[],captcha:false,loginPrompt:false};scrolls++;buffer=make();return '';},waitForSelector:async()=>{},waitForFunction:async()=>{},cdp:async(method,arg)=>{if(method==='Network.enable')return {};if(failBody&&arg.requestId==='1')throw Error('missing body');return {body:JSON.stringify({status_code:0,has_more:0,cursor:12,item_list:[]})};}}};
}
for(const statuses of [[429],[401]])test('访问-ACCESS-003 document '+statuses[0]+' wins over API403',async t=>{
 const p=pageFixture({statuses,apiStatuses:[403]}),waits=[];const b=fn('createEgoBrowser')({page:p.page,runDir:await temp(t),sleep:async ms=>waits.push(ms)});
 await assert.rejects(b.discoverBatch({keyword:'christian skits'}),new RegExp(String(statuses[0])));assert.equal(p.nav,1);assert(!waits.includes(11000));
});
test('完成-DONE-003 partial bodies cannot mark search exhausted',async t=>{
 const p=pageFixture({apiStatuses:[200,200],failBody:true}),b=fn('createEgoBrowser')({page:p.page,runDir:await temp(t),sleep:async()=>{}});
 await assert.rejects(b.discoverBatch({keyword:'christian skits'}),/response|body/i);
});
test('来源-SOURCE-001 old keyword response cannot finish the current word',async t=>{
 const p=pageFixture({queries:['old query']}),b=fn('createEgoBrowser')({page:p.page,runDir:await temp(t),sleep:async()=>{}});await assert.rejects(b.discoverBatch({keyword:'christian skits'}),/provenance|source|missing/i);
});
test('访问-ACCESS-001/004 same-address 403 gets one delayed retry, budget persists',async t=>{
 const p=pageFixture({statuses:[403],apiStatuses:[403]}),waits=[];let checkpoint;
 const b=fn('createEgoBrowser')({page:p.page,runDir:await temp(t),sleep:async ms=>waits.push(ms)});
 await assert.rejects(b.discoverBatch({keyword:'christian skits',onCheckpoint:async c=>checkpoint=c}),/403/);assert.equal(p.nav,2);assert.equal(waits.filter(x=>x===11000).length,1);
 await assert.rejects(b.discoverBatch({keyword:'christian skits',checkpoint}),/403/);assert.equal(p.nav,2);
});
test('节奏-PACE-001 actual navigations share a serialized 10.5 second clock',async t=>{
 const p=pageFixture(),times=[],runDir=await temp(t);let tick=20000;const original=p.page.goto;p.page.goto=async url=>{times.push(tick);return original(url);};
 const b=fn('createEgoBrowser')({page:p.page,runDir,now:()=>tick,sleep:async ms=>{tick+=ms;}});
 await b.discoverBatch({keyword:'christian skits'});await b.discoverBatch({keyword:'christian skits'});assert(times[1]-times[0]>=10500);
});
test('访问-ACCESS-004 profile 403 budget survives restarting the browser adapter',async t=>{
 const p=pageFixture({statuses:[403],apiStatuses:[403]}),runDir=await temp(t);let checkpoint,tick=20000;
 p.page.evaluate=async f=>f.name==='readSearchPage'?{url:'https://www.tiktok.com/@example',httpStatus:403}:capture().profile;
 const options={page:p.page,runDir,now:()=>tick,sleep:async ms=>tick+=ms};
 await assert.rejects(fn('createEgoBrowser')(options).readProfile({username:'example'},async c=>checkpoint=c),/403/);assert.equal(p.nav,2);
 await assert.rejects(fn('createEgoBrowser')(options).readProfile({username:'example'},async()=>{},checkpoint),/403/);assert.equal(p.nav,2);
});
test('身份-ID-001 real adapter reads profile and post fields; optional email is honored',async t=>{
 const c=capture();c.profile.bio='Christian skits';let buffer=[],url='',nav=0,profileReads=0;
 const item=c.pages[0].items[0];
 const page={goto:async u=>{url=u;nav++;buffer=[{method:'Network.requestWillBeSent',params:{requestId:'posts',documentURL:u}},{method:'Network.responseReceived',params:{requestId:'posts',response:{url:'https://www.tiktok.com/api/post/item_list/?secUid=public',status:200}}},{method:'Network.loadingFinished',params:{requestId:'posts'}}];},events:async()=>{const out=buffer;buffer=[];return out;},url:async()=>url,evaluate:async f=>f.name==='readSearchPage'?{url,httpStatus:200}:(++profileReads<=2?{}:c.profile),cdp:async m=>m==='Network.enable'?{}:{body:JSON.stringify({statusCode:0,hasMore:false,itemList:[{id:item.id,author:{id:item.authorId,uniqueId:item.username},createTime:item.createdAt,stats:{playCount:60000},desc:'#christianskit',locationCreated:'US'}]})}};
 let tick=20000;const browser=fn('createEgoBrowser')({page,runDir:await temp(t),config:{...config,requireBioEmail:false},now:()=>tick,sleep:async ms=>tick+=ms});
 const {qualifyCandidate}=await import('./profile.mjs');const r=await qualifyCandidate({candidate:candidate(),config:{...config,requireBioEmail:false},browser});assert.equal(r.decision,'confirmed');assert.equal(nav,1);assert.equal(r.metrics.sampleSize,1);
});
test('空间-EGO-001 runner chooses p1 and refuses user-owned spaces',async t=>{
 const run=fn('runInEgo'),runDir=await temp(t);let labels=[];
 await assert.rejects(run({spaceId:5,runDir},{listTaskSpaces:async()=>[{id:5,ownership:'user'}],taskSpace:async()=>{throw Error('must not connect');}}),/control|ownership/i);
 const p=pageFixture();await assert.rejects(run({spaceId:5,runDir,config:{}},{listTaskSpaces:async()=>[{id:5,ownership:'agent'}],taskSpace:async()=>({page:label=>{labels.push(label);return p.page;},finish:async()=>{}})}));assert.deepEqual(labels,['p1']);
});
